<!--
 * @Author: chenzhongsheng
 * @Date: 2022-11-21 17:52:04
 * @Description: Coding something
 * @LastEditors: chenzhongsheng
 * @LastEditTime: 2022-12-01 23:20:54
-->
### 🚀 [webos-term](https://github.com/theajack/webos): HTML5 FileSystem-based web terminal window

webos-term Chrome extension